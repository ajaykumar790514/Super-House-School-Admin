<style>
.fa {
  margin-left: -12px;
  margin-right: 8px;
}

</style>
<div class="row">
    <div class="col-md-6 text-left">
        <span>Showing <?=$page+1?> to <?=$page+count($stock_report)?> of <?=$total_rows?> entries</span>
    </div>
    <div class="col-md-6 text-right">
        <div class="col-md-4" style="float: left; margin: 12px 0px;">
            <input type="text" class="form-control" name="tb-search" id="tb-search" value="<?=$search?>" placeholder="Search...">
        </div>
        <div class="col-md-8 text-right" style="float: left;">
            <?=$links?>
        </div>
        
    </div>
    <div class="col-md-12">
        <a href="<?= base_url('reports/stock_report/export_to_excel'); ?>" class="btn btn-primary btn-sm mb-3"><i class="fas fa-arrow-down"></i> Export to Excel</a>
    </div>
</div>


<div id="grid_table" class="table-responsive">
    <table class="jsgrid-table">
        <tr class="jsgrid-header-row">
            <th class="jsgrid-header-cell jsgrid-align-center">S.No.</th>
            <th class="jsgrid-header-cell jsgrid-align-center">Product Name</th>
            <th class="jsgrid-header-cell jsgrid-align-center">Sale Price</th>
            <th class="jsgrid-header-cell jsgrid-align-center">Product Code</th>
            <th class="jsgrid-header-cell jsgrid-align-center">Pack Size</th>
            <th class="jsgrid-header-cell jsgrid-align-center">Stock</th>
        </tr>
        
        <?php $i=$page; foreach($stock_report as $value){ ?>
        <tr class="jsgrid-filter-row">
            <th class="jsgrid-cell jsgrid-align-center"><?=++$i?></th>
            <td class="jsgrid-cell jsgrid-align-center"><b><?php echo $value->prod_name;?></b> (<?php echo $value->cat_name;?>)</td>
            <td class="jsgrid-cell jsgrid-align-center">₹ <?php echo $value->selling_rate;?></td>
            <td class="jsgrid-cell jsgrid-align-center"><?php echo $value->product_code;?></td>
            <td class="jsgrid-cell jsgrid-align-center"><?php echo $value->unit_value.' '.$value->unit_type;?></td>
            <th class="jsgrid-cell jsgrid-align-center" style="color:red;"><?php echo $value->qty;?></th>
            
        </tr> 
        <?php } ?>    
    </table>

        
</div>
<div class="row">
    <div class="col-md-6 text-left">
        <span>Showing <?=$page+1?> to <?=$page+count($stock_report)?> of <?=$total_rows?> entries</span>
    </div>
    <div class="col-md-6 text-right">
        <?=$links?>
    </div>
</div>



