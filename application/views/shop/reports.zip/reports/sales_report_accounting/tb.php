<style>
.fa {
  margin-left: -12px;
  margin-right: 8px;
}
.jsgrid-table
{
    width:166%;
}
</style>
<div class="row">
    <div class="col-md-6 text-left">
        <!-- <span>Showing <?=$page+1?> to <?=$page+count($sales_report_accounting)?> of <?=$total_rows?> entries</span> -->
    </div>
    <div class="col-md-6 text-right">
        <div class="col-md-4" style="float: left; margin: 12px 0px;">
            <!-- <input type="text" class="form-control" name="tb-search" id="tb-search" value="<?=$search?>" placeholder="Search..."> -->
        </div>
        <div class="col-md-8 text-right" style="float: left;">
            <!-- <?=$links?> -->
        </div>
       
    </div>
</div>
<div class="row">
        <div class="col-3">
            <div class="form-group">
                <label class="control-label">From date:</label>
                <input type="date" class="form-control" name="from_date" id="from_date" value="<?php if(!empty($from_date)){echo $from_date; }?>">
            </div>
            <div id="msg"></div>
        </div>

        <div class="col-3">
            <div class="form-group">
                <label class="control-label">To date:</label>
                <input type="date" class="form-control" name="to_date" id="to_date" value="<?php if(!empty($to_date)){echo $to_date; }?>" onchange="filter_sales_report_accounting(this.value)">
            </div>
        </div>

        <div class="col-3">
            <div class="form-group">
            <label class="control-label">Payment Mode:</label>
            <select class="form-control" style="width:100%;" name="pm_id" id="pm_id" onchange="filter_by_payment_mode(this.value)">
            <option value="">Select</option>
            <option value="cod" <?php if(!empty($pmid)){if($pmid == 'cod'){echo "selected";} }?>>COD</option>
            <option value="online" <?php if(!empty($pmid)){if($pmid == 'online'){echo "selected";} }?>>Online</option>
            
            </select>
            </div>
        </div>
</div>

<div id="datatable">
    <?php if(!empty($to_date)) { ?>
        <div class="row">
            <div class="col-md-12">
            <a href="<?= base_url('reports/sales_report_accounting/export_to_excel/'.$from_date.'/'.$to_date.'/'.$pmid); ?>" class="btn btn-primary btn-sm mb-3"><i class="fas fa-arrow-down"></i> Export to Excel</a>
            </div>
        </div>
    <div id="grid_table" class="table-responsive">

        <table class="jsgrid-table">
            <tr class="jsgrid-header-row">
                <th class="jsgrid-header-cell jsgrid-align-center">S.No.</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Invoice No.</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Customer name</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Customer number</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Order date</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Product code</th>
                <th class="jsgrid-header-cell jsgrid-align-center">SKU</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Qty</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Unit Price without tax</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Total without tax</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Igst rate</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Cgst rate</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Sgst rate</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Igst value</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Cgst value</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Sgst value</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Total tax</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Total value with tax</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Payment Method</th>
                <th class="jsgrid-header-cell jsgrid-align-center">Bank Name</th>
            </tr>
            
            <?php $i=$page; foreach($sales_report_accounting as $value){ 

                $purchase_rate = $value->purchase_rate;
                $tax =  $value->tax_value;
                $inclusive_tax = $purchase_rate - ($purchase_rate * (100/ (100 + $tax)));

                $unit_price_without_tax =  $purchase_rate - $inclusive_tax;
                $total_without_tax = $unit_price_without_tax * $value->qty;
                

                if($value->is_igst == 1)
                {
                    $igst = $value->tax_value;
                    $cgst = 0;$sgst = 0;
                    $cgst_val = 0;$sgst_val = 0;
                    $igst_val = $inclusive_tax;
                }
                else if($value->is_igst == 0)
                {
                    $cgst = $value->tax_value/2;
                    $sgst =$value->tax_value/2;
                    $cgst_val = $inclusive_tax/2;
                    $sgst_val = $inclusive_tax /2;
                    $igst=0;$igst_val=0;
                }

                $total_tax = $inclusive_tax*$value->qty;
                $total_value_with_tax = $total_without_tax + $total_tax;







                ?>
            <tr class="jsgrid-filter-row">
                <th class="jsgrid-cell jsgrid-align-center"><?=++$i;?></th>
                <td class="jsgrid-cell jsgrid-align-center"><?= $value->orderid; ?> </td>
                <td class="jsgrid-cell jsgrid-align-center"><?= $value->fname.' '.$value->lname ?> </td>
                <td class="jsgrid-cell jsgrid-align-center"><?= $value->mobile; ?> </td>
                <td class="jsgrid-cell jsgrid-align-center"><?= date('d-m-Y',strtotime($value->order_date));?> </td>
                <td class="jsgrid-cell jsgrid-align-center"><?= $value->product_code; ?> </td>
                <td class="jsgrid-cell jsgrid-align-center"><?= $value->sku; ?> </td>
                <td class="jsgrid-cell jsgrid-align-center"><?= $value->qty; ?> </td>
                <td class="jsgrid-cell jsgrid-align-center">₹ <?= round($unit_price_without_tax,2); ?></td>
                <td class="jsgrid-cell jsgrid-align-center">₹ <?= round($total_without_tax,2); ?></td>
                <td class="jsgrid-cell jsgrid-align-center"><?= round($igst, 2); ?> %</td>
                <td class="jsgrid-cell jsgrid-align-center"><?= round($cgst, 2); ?> %</td>
                <td class="jsgrid-cell jsgrid-align-center"><?= round($sgst, 2); ?> %</td>
                <td class="jsgrid-cell jsgrid-align-center">₹ <?= round($igst_val, 2); ?></td>
                <td class="jsgrid-cell jsgrid-align-center">₹ <?= round($cgst_val, 2); ?></td>
                <td class="jsgrid-cell jsgrid-align-center">₹ <?= round($sgst_val, 2); ?></td>
                <td class="jsgrid-cell jsgrid-align-center">₹ <?= round($total_tax,2); ?></td>
                <td class="jsgrid-cell jsgrid-align-center">₹ <?= round($total_value_with_tax,2); ?></td>
                <td class="jsgrid-cell jsgrid-align-center"><?= $value->payment_method; ?></td>
                <td class="jsgrid-cell jsgrid-align-center"><?= $value->bank_name; ?></td>
                
            </tr> 
            <?php } ?>    
        </table>

    </div>
</div>
<div class="row">
    <div class="col-md-6 text-left">
        <span>Showing <?=$page+1?> to <?=$page+count($sales_report_accounting)?> of <?=$total_rows?> entries</span>
    </div>
    <div class="col-md-6 text-right">
        <?=$links?>
    </div>
</div>
<?php } ?>
<script type="text/javascript">
   function filter_sales_report_accounting(to_date)
   {
    if(document.getElementById('from_date').value == 0)
    {
        alert('Please Select From Date');
        document.getElementById('from_date').focus();
        $('#to_date').prop('value',0);
        return false;
    }
    $("#datatable").html('<div class="text-center"><img src="loader.gif"></div>');
    var from_date = $("#from_date").val();
    var pm_id = $("#pm_id").val();
    if(from_date>to_date)
    {
        msg = "From date should be less than to date";
        document.getElementById('msg').style.color='red';
        document.getElementById('msg').innerHTML=msg;
        return;
    }
    $.ajax({
        url: "<?php echo base_url('reports/sales_report_accounting/tb'); ?>",
        method: "POST",
        data: {
            from_date:from_date,
            to_date:to_date,
            pm_id:pm_id
        },
        success: function(data){
            $("#tb").html(data);
        },
    });
   }
</script>


<script type="text/javascript">
   function filter_by_payment_mode(pm_id)
   {
    $("#datatable").html('<div class="text-center"><img src="loader.gif"></div>');
    var from_date = $("#from_date").val();
    var to_date = $('#to_date').val();
    $.ajax({
        url: "<?php echo base_url('reports/sales_report_accounting/tb'); ?>",
        method: "POST",
        data: {
            from_date:from_date,
            to_date:to_date,
            pm_id:pm_id
        },
        success: function(data){
            $("#tb").html(data);
        },
    });
   }
</script>

